﻿using System;
using System.IO;
using System.Windows.Forms;

namespace SystemCallInterface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Create File
        private void button1_Click(object sender, EventArgs e)
        {
            string path = "C:\\Users\\Public\\testfile.txt";
            try
            {
                if (!File.Exists(path))
                {
                    File.Create(path).Close();
                    MessageBox.Show($"✅ File created: {path}");
                }
                else
                {
                    MessageBox.Show($"ℹ️ File already exists: {path}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Error: {ex.Message}");
            }
        }

        // Write File
        private void btnWriteFile_Click(object sender, EventArgs e)
        {
            string path = "C:\\Users\\Public\\testfile.txt";
            string contentToWrite = txtInput.Text;

            try
            {
                File.WriteAllText(path, contentToWrite);
                txtOutput.Text = $"✅ File written successfully!\n\n🧠 WriteFile: This function writes content into a file (overwrites if it already exists).";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Read File
        private void btnReadFile_Click(object sender, EventArgs e)
        {
            string path = "C:\\Users\\Public\\testfile.txt";
            try
            {
                if (File.Exists(path))
                {
                    string content = File.ReadAllText(path);
                    txtOutput.Text = $"📄 File Content:\n{content}\n\n🧠 ReadFile: Reads the content of a file.";
                }
                else
                {
                    MessageBox.Show($"⚠️ File not found: {path}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Error: {ex.Message}");
            }
        }

        // Close App
        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
